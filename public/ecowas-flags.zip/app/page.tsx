import { FlagCard } from "@/components/flag-card"

const ecowasCountries = [
  { name: "Bénin", code: "bj", capital: "Porto-Novo" },
  { name: "Burkina Faso", code: "bf", capital: "Ouagadougou" },
  { name: "Cap-Vert", code: "cv", capital: "Praia" },
  { name: "Côte d'Ivoire", code: "ci", capital: "Yamoussoukro" },
  { name: "Gambie", code: "gm", capital: "Banjul" },
  { name: "Ghana", code: "gh", capital: "Accra" },
  { name: "Guinée", code: "gn", capital: "Conakry" },
  { name: "Guinée-Bissau", code: "gw", capital: "Bissau" },
  { name: "Libéria", code: "lr", capital: "Monrovia" },
  { name: "Mali", code: "ml", capital: "Bamako" },
  { name: "Niger", code: "ne", capital: "Niamey" },
  { name: "Nigéria", code: "ng", capital: "Abuja" },
  { name: "Sénégal", code: "sn", capital: "Dakar" },
  { name: "Sierra Leone", code: "sl", capital: "Freetown" },
  { name: "Togo", code: "tg", capital: "Lomé" },
]

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <p className="text-sm font-medium uppercase tracking-widest text-muted-foreground">
            CEDEAO / ECOWAS
          </p>
          <h1 className="mt-2 text-3xl font-bold text-balance text-foreground md:text-4xl">
            Les drapeaux des 15 pays de la CEDEAO
          </h1>
          <p className="mt-3 max-w-2xl leading-relaxed text-muted-foreground">
            Tous les drapeaux des pays membres de la Communauté économique des
            États de l&apos;Afrique de l&apos;Ouest, au format SVG. Cliquez sur
            un drapeau pour ouvrir le fichier SVG, ou utilisez le lien pour le
            télécharger.
          </p>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 py-10">
        <ul className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {ecowasCountries.map((country) => (
            <li key={country.code}>
              <FlagCard
                name={country.name}
                code={country.code}
                capital={country.capital}
              />
            </li>
          ))}
        </ul>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-6">
          <p className="text-sm text-muted-foreground">
            Fichiers SVG fournis par flagcdn.com — utilisation libre.
          </p>
        </div>
      </footer>
    </main>
  )
}
