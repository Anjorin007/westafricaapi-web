import { Download } from "lucide-react"

interface FlagCardProps {
  name: string
  code: string
  capital: string
}

export function FlagCard({ name, code, capital }: FlagCardProps) {
  const svgUrl = `https://flagcdn.com/${code}.svg`

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-lg border border-border bg-card">
      <a
        href={svgUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="block aspect-[3/2] overflow-hidden bg-muted"
        aria-label={`Ouvrir le drapeau SVG de ${name}`}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={svgUrl || "/placeholder.svg"}
          alt={`Drapeau de ${name}`}
          className="h-full w-full object-cover transition-transform duration-200 hover:scale-105"
          loading="lazy"
        />
      </a>
      <div className="flex flex-1 items-center justify-between gap-2 p-4">
        <div>
          <h2 className="font-semibold text-card-foreground">{name}</h2>
          <p className="text-sm text-muted-foreground">{capital}</p>
        </div>
        <a
          href={svgUrl}
          download={`${code}.svg`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-muted"
          aria-label={`Télécharger le drapeau SVG de ${name}`}
        >
          <Download className="h-4 w-4" aria-hidden="true" />
          SVG
        </a>
      </div>
    </div>
  )
}
