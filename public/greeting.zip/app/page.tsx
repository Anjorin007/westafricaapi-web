import { Logo, LogoMark } from '@/components/logo'

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      {/* Navbar */}
      <header className="border-b border-border">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <a href="/" aria-label="WestAfrica API — Accueil">
            <Logo size={30} />
          </a>
          <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
            <a href="#" className="hover:text-foreground">Docs</a>
            <a href="#" className="hover:text-foreground">Tarifs</a>
            <a href="#" className="hover:text-foreground">Contact</a>
          </div>
        </nav>
      </header>

      {/* Preview area */}
      <main className="flex flex-1 flex-col items-center justify-center gap-10 px-6 py-16">
        <div className="flex flex-col items-center gap-6">
          <Logo size={56} />
          <p className="max-w-md text-center text-sm leading-relaxed text-muted-foreground text-pretty">
            Logo 100% SVG avec fond transparent. Le pin s&apos;adapte
            automatiquement au mode clair ou sombre via{' '}
            <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">currentColor</code>.
          </p>
        </div>

        <div className="flex items-center gap-8">
          <div className="flex flex-col items-center gap-2">
            <LogoMark size={48} />
            <span className="text-xs text-muted-foreground">Icône seule</span>
          </div>
          <div className="flex flex-col items-center gap-2 rounded-lg bg-foreground px-6 py-4 text-background">
            <Logo size={28} />
            <span className="text-xs opacity-70">Fond inversé</span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 md:flex-row">
          <Logo size={24} />
          <p className="text-xs text-muted-foreground">
            © 2026 WestAfrica API. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
