import { AFRICA_REST_PATH, ECOWAS_PATHS } from './logo-map-data'

interface LogoProps {
  /** Height of the logo in pixels. Width scales automatically. */
  size?: number
  /** Show the "WestAfrica API" wordmark next to the icon */
  showText?: boolean
  className?: string
}

/**
 * WestAfrica API logo — real Africa map (Natural Earth data), transparent background.
 * The rest of the continent renders subtly with `currentColor`,
 * while the 14 mainland ECOWAS countries stand out in teal with visible borders.
 */
export function Logo({ size = 32, showText = true, className }: LogoProps) {
  return (
    <span
      className={className}
      style={{ display: 'inline-flex', alignItems: 'center', gap: size * 0.3 }}
    >
      <LogoMark size={size} />
      {showText && (
        <span
          style={{
            fontSize: size * 0.62,
            fontWeight: 700,
            letterSpacing: '-0.02em',
            lineHeight: 1,
            whiteSpace: 'nowrap',
          }}
        >
          WestAfrica <span style={{ color: '#2dd4bf' }}>API</span>
        </span>
      )}
    </span>
  )
}

/** Icon only — real map of Africa with ECOWAS countries highlighted in teal */
export function LogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="WestAfrica API — carte de l'Afrique avec les pays de la CEDEAO en surbrillance"
    >
      {/* Rest of Africa — subtle, adapts to light/dark via currentColor */}
      <path d={AFRICA_REST_PATH} fill="currentColor" opacity="0.22" />

      {/* ECOWAS member states — teal fill with readable borders */}
      <g fill="#14b8a6" stroke="#5eead4" strokeWidth="0.6" strokeLinejoin="round">
        {ECOWAS_PATHS.map((c) => (
          <path key={c.name} d={c.d}>
            <title>{c.name}</title>
          </path>
        ))}
      </g>
    </svg>
  )
}
