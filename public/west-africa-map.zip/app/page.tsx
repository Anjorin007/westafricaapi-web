import { AfricaMap } from "@/components/africa-map"
import { countries } from "@/lib/africa-data"

export default function Page() {
  const westAfrican = countries.filter((c) => c.westAfrica).sort((a, b) => a.name.localeCompare(b.name, "fr"))

  return (
    <main className="min-h-svh bg-background px-4 py-10">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-8">
        <header className="text-center">
          <h1 className="text-balance text-3xl font-bold text-foreground">
            Les 16 pays d&apos;Afrique de l&apos;Ouest
          </h1>
          <p className="mt-2 text-pretty text-muted-foreground">
            Identifiés sur la carte 3D — mis en évidence en vert
          </p>
        </header>

        <div className="grid w-full items-start gap-8 lg:grid-cols-[1fr_280px]">
          <AfricaMap />

          <aside className="rounded-lg border border-border bg-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Pays identifiés ({westAfrican.length + 1}/16)
            </h2>
            <ol className="mt-3 grid gap-1.5 text-sm text-card-foreground">
              {westAfrican.map((c) => (
                <li key={c.id} className="flex items-center gap-2">
                  <span aria-hidden="true" className="size-2.5 shrink-0 rounded-full bg-[#16a34a]" />
                  {c.name}
                </li>
              ))}
              <li className="flex items-center gap-2 text-muted-foreground">
                <span aria-hidden="true" className="size-2.5 shrink-0 rounded-full border border-dashed border-muted-foreground" />
                Cap-Vert (îles non dessinées sur cette carte)
              </li>
            </ol>
          </aside>
        </div>
      </div>
    </main>
  )
}
