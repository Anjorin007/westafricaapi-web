"use client"

import { useState } from "react"
import { countries, SHADOW_D, EXTRUSION_D } from "@/lib/africa-data"

export function AfricaMap() {
  const [hovered, setHovered] = useState<string | null>(null)

  return (
    <div className="flex w-full flex-col items-center gap-2">
      <div
        className="h-8 rounded-md bg-card px-4 py-1.5 text-sm font-medium text-card-foreground shadow-sm"
        aria-live="polite"
      >
        {hovered ?? "Survolez un pays"}
      </div>
      <svg
        viewBox="0 0 1000 1000"
        role="img"
        aria-label="Carte 3D de l'Afrique avec les pays d'Afrique de l'Ouest mis en évidence"
        className="w-full max-w-2xl"
      >
        <defs>
          <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="10" dy="18" stdDeviation="14" floodColor="#000" floodOpacity="0.28" />
          </filter>
        </defs>
        {/* ombre portée */}
        <g filter="url(#softShadow)">
          <path d={SHADOW_D} fill="#6b6b6e" />
        </g>
        {/* épaisseur 3D */}
        <g transform="translate(-7,11)">
          <path d={EXTRUSION_D} fill="#c9c9cb" />
        </g>
        {/* face supérieure : pays */}
        <g strokeLinejoin="round">
          {countries.map((c) => (
            <path
              key={c.id}
              d={c.d}
              stroke={c.westAfrica ? "#15803d" : "#8a8a8c"}
              strokeWidth={1.6}
              fill={
                hovered === c.name
                  ? c.westAfrica
                    ? "#22c55e"
                    : "#d6d6d4"
                  : c.westAfrica
                    ? "#bbf7d0"
                    : "#f5f5f4"
              }
              className="cursor-pointer transition-[fill] duration-150"
              onMouseEnter={() => setHovered(c.name)}
              onMouseLeave={() => setHovered(null)}
            >
              <title>{c.name}</title>
            </path>
          ))}
        </g>
      </svg>
    </div>
  )
}
