// Generate lib/africa-data.ts: every SVG path annotated with its country name.
import { readFileSync, writeFileSync } from "node:fs"

const matches = JSON.parse(readFileSync("scripts/matches.json", "utf8"))
const svg = readFileSync("public/afrique-3d.svg", "utf8")
const topGroup = svg.match(/<!-- face superieure : pays -->\s*<g[^>]*>([\s\S]*?)<\/g>/)[1]
const dList = [...topGroup.matchAll(/d="([^"]+)"/g)].map((m) => m[1])
const shadowD = svg.match(/<!-- ombre portee -->\s*<g[^>]*>\s*<path d="([^"]+)"/)[1]
const extrusionD = svg.match(/<!-- epaisseur 3D \(extrusion\) -->\s*<g[^>]*>\s*<path d="([^"]+)"/)[1]

const fr = {
  "Morocco": "Maroc", "Algeria": "Algérie", "Tunisia": "Tunisie", "Libya": "Libye", "Egypt": "Égypte",
  "W. Sahara": "Sahara occidental", "Mauritania": "Mauritanie", "Mali": "Mali", "Niger": "Niger",
  "Chad": "Tchad", "Sudan": "Soudan", "Senegal": "Sénégal", "Gambia": "Gambie",
  "Guinea-Bissau": "Guinée-Bissau", "Guinea": "Guinée", "Sierra Leone": "Sierra Leone",
  "Liberia": "Liberia", "Côte d'Ivoire": "Côte d'Ivoire", "Ghana": "Ghana", "Togo": "Togo",
  "Benin": "Bénin", "Burkina Faso": "Burkina Faso", "Nigeria": "Nigeria", "Cameroon": "Cameroun",
  "Central African Rep.": "République centrafricaine", "S. Sudan": "Soudan du Sud",
  "Ethiopia": "Éthiopie", "Eritrea": "Érythrée", "Djibouti": "Djibouti", "Somalia": "Somalie",
  "Kenya": "Kenya", "Uganda": "Ouganda", "Rwanda": "Rwanda", "Burundi": "Burundi",
  "Tanzania": "Tanzanie", "Dem. Rep. Congo": "RD Congo", "Congo": "Congo", "Gabon": "Gabon",
  "Eq. Guinea": "Guinée équatoriale", "Angola": "Angola", "Zambia": "Zambie", "Malawi": "Malawi",
  "Mozambique": "Mozambique", "Zimbabwe": "Zimbabwe", "Botswana": "Botswana", "Namibia": "Namibie",
  "South Africa": "Afrique du Sud", "Lesotho": "Lesotho", "eSwatini": "Eswatini", "Madagascar": "Madagascar",
}
const westAfrica = new Set([
  "Bénin","Burkina Faso","Côte d'Ivoire","Gambie","Ghana","Guinée","Guinée-Bissau",
  "Liberia","Mali","Mauritanie","Niger","Nigeria","Sénégal","Sierra Leone","Togo",
])

const countries = matches.map((m) => {
  const name = fr[m.country] ?? m.country
  return { id: m.pathIndex, name, westAfrica: westAfrica.has(name), d: dList[m.pathIndex] }
})

const ts = `// Généré automatiquement par scripts/generate-data.mjs
// Chaque tracé du SVG "afrique-3d" identifié par correspondance géographique
// (projection équirectangulaire ajustée + correction affine + affectation hongroise).

export type Country = {
  id: number
  name: string
  westAfrica: boolean
  d: string
}

export const SHADOW_D = ${JSON.stringify(shadowD)}

export const EXTRUSION_D = ${JSON.stringify(extrusionD)}

export const countries: Country[] = ${JSON.stringify(countries, null, 2)}
`
writeFileSync("lib/africa-data.ts", ts)
console.log("wrote lib/africa-data.ts with", countries.length, "countries;", countries.filter((c) => c.westAfrica).length, "West African")
