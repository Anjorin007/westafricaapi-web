// Identify which SVG path is which African country:
// 1) fit equirectangular projection to the SVG bbox
// 2) find high-confidence anchors via geoContains
// 3) least-squares affine correction (geo -> svg space)
// 4) optimal one-to-one assignment (Hungarian) with distance + area cost
import { readFileSync, writeFileSync } from "node:fs"
import * as topojson from "topojson-client"
import { geoEquirectangular, geoPath, geoContains } from "d3-geo"
import { createRequire } from "node:module"

const require = createRequire(import.meta.url)
const munkres = require("munkres-js")
const world = require("world-atlas/countries-50m.json")
const countries = topojson.feature(world, world.objects.countries)

// --- Parse SVG top-face paths ---
const svg = readFileSync("public/afrique-3d.svg", "utf8")
const topGroup = svg.match(/<!-- face superieure : pays -->\s*<g[^>]*>([\s\S]*?)<\/g>/)[1]
const dList = [...topGroup.matchAll(/d="([^"]+)"/g)].map((m) => m[1])

const parseSubpaths = (d) =>
  d.split(/(?=M)/).filter(Boolean).map((s) => [...s.matchAll(/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/g)].map((m) => [+m[1], +m[2]]))
function polyArea(pts) {
  let a = 0
  for (let i = 0; i < pts.length; i++) { const [x1, y1] = pts[i], [x2, y2] = pts[(i + 1) % pts.length]; a += x1 * y2 - x2 * y1 }
  return a / 2
}
function polyCentroid(pts) {
  let a = 0, cx = 0, cy = 0
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i], [x2, y2] = pts[(i + 1) % pts.length]
    const c = x1 * y2 - x2 * y1; a += c; cx += (x1 + x2) * c; cy += (y1 + y2) * c
  }
  a /= 2
  return [cx / (6 * a), cy / (6 * a)]
}

const svgShapes = dList.map((d, i) => {
  const subs = parseSubpaths(d)
  let best = subs[0], bestA = 0, totalA = 0
  for (const s of subs) { const a = Math.abs(polyArea(s)); totalA += a; if (a > bestA) { bestA = a; best = s } }
  const [cx, cy] = polyCentroid(best)
  const xs = subs.flat().map((p) => p[0]), ys = subs.flat().map((p) => p[1])
  return { index: i, cx, cy, area: totalA, bbox: [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)] }
})
const allX = svgShapes.flatMap((s) => [s.bbox[0], s.bbox[2]])
const allY = svgShapes.flatMap((s) => [s.bbox[1], s.bbox[3]])
const mapBBox = [[Math.min(...allX), Math.min(...allY)], [Math.max(...allX), Math.max(...allY)]]

const africanNames = [
  "Morocco","Algeria","Tunisia","Libya","Egypt","W. Sahara","Mauritania","Mali","Niger","Chad","Sudan",
  "Senegal","Gambia","Guinea-Bissau","Guinea","Sierra Leone","Liberia","Côte d'Ivoire","Ghana","Togo","Benin","Burkina Faso",
  "Nigeria","Cameroon","Central African Rep.","S. Sudan","Ethiopia","Eritrea","Djibouti","Somalia","Somaliland",
  "Kenya","Uganda","Rwanda","Burundi","Tanzania","Dem. Rep. Congo","Congo","Gabon","Eq. Guinea",
  "Angola","Zambia","Malawi","Mozambique","Zimbabwe","Botswana","Namibia","South Africa","Lesotho","eSwatini","Madagascar",
]
const african = countries.features.filter((f) => africanNames.includes(f.properties.name))
const proj = geoEquirectangular().fitExtent(mapBBox, { type: "FeatureCollection", features: african })
const gpath = geoPath(proj)
const geo = african.map((f) => {
  const c = gpath.centroid(f)
  return { name: f.properties.name, cx: c[0], cy: c[1], area: gpath.area(f), feature: f }
})

// --- Anchors: svg centroid inverse-projected lands inside a country, and that
// country's projected centroid is the closest one (mutual agreement)
const anchors = []
for (const s of svgShapes) {
  const ll = proj.invert([s.cx, s.cy])
  const container = african.find((f) => geoContains(f, ll))
  if (!container) continue
  const g = geo.find((x) => x.name === container.properties.name)
  const ratio = s.area / g.area
  if (ratio > 0.9 && ratio < 2.2) anchors.push({ s, g })
}
console.log("anchors:", anchors.length, anchors.map((a) => `${a.s.index}:${a.g.name}`).join(" "))

// --- Least-squares affine geo->svg from anchors: [x'] = a*x + b*y + c ; [y'] = d*x + e*y + f
function fitAffine(pairs) {
  // solve two independent 3-var least squares
  let Sxx = 0, Sxy = 0, Sx = 0, Syy = 0, Sy = 0, N = pairs.length
  let SxX = 0, SyX = 0, SX = 0, SxY = 0, SyY = 0, SY = 0
  for (const { s, g } of pairs) {
    Sxx += g.cx * g.cx; Sxy += g.cx * g.cy; Sx += g.cx; Syy += g.cy * g.cy; Sy += g.cy
    SxX += g.cx * s.cx; SyX += g.cy * s.cx; SX += s.cx
    SxY += g.cx * s.cy; SyY += g.cy * s.cy; SY += s.cy
  }
  const M = [[Sxx, Sxy, Sx], [Sxy, Syy, Sy], [Sx, Sy, N]]
  function solve3(M, v) {
    const m = M.map((r) => [...r])
    const b = [...v]
    for (let i = 0; i < 3; i++) {
      let p = i
      for (let r = i + 1; r < 3; r++) if (Math.abs(m[r][i]) > Math.abs(m[p][i])) p = r
      ;[m[i], m[p]] = [m[p], m[i]]; [b[i], b[p]] = [b[p], b[i]]
      for (let r = i + 1; r < 3; r++) {
        const f = m[r][i] / m[i][i]
        for (let c = i; c < 3; c++) m[r][c] -= f * m[i][c]
        b[r] -= f * b[i]
      }
    }
    const x = [0, 0, 0]
    for (let i = 2; i >= 0; i--) {
      x[i] = (b[i] - m[i].slice(i + 1).reduce((s, mv, k) => s + mv * x[i + 1 + k], 0)) / m[i][i]
    }
    return x
  }
  const [a, b1, c] = solve3(M, [SxX, SyX, SX])
  const [d, e, f] = solve3(M, [SxY, SyY, SY])
  return ([x, y]) => [a * x + b1 * y + c, d * x + e * y + f]
}
const affine = fitAffine(anchors)

// median area ratio from anchors
const ratios = anchors.map((a) => a.s.area / a.g.area).sort((x, y) => x - y)
const medRatio = ratios[Math.floor(ratios.length / 2)]
console.log("median area ratio:", medRatio.toFixed(3))

// --- Hungarian assignment ---
const BIG = 1e6
const cost = svgShapes.map((s) =>
  geo.map((g) => {
    const [gx, gy] = affine([g.cx, g.cy])
    const dist = Math.hypot(s.cx - gx, s.cy - gy)
    const areaPen = Math.abs(Math.log((s.area / g.area) / medRatio)) * 60
    return Math.min(dist + areaPen, BIG)
  })
)
const assignment = munkres(cost)
const out = assignment
  .map(([si, gi]) => ({
    pathIndex: si,
    country: geo[gi].name,
    dist: +Math.hypot(svgShapes[si].cx - affine([geo[gi].cx, geo[gi].cy])[0], svgShapes[si].cy - affine([geo[gi].cx, geo[gi].cy])[1]).toFixed(1),
    areaRatio: +(svgShapes[si].area / geo[gi].area / medRatio).toFixed(2),
    cost: +cost[si][gi].toFixed(1),
  }))
  .sort((a, b) => a.pathIndex - b.pathIndex)
console.table(out)
const unassignedGeo = geo.filter((g, gi) => !assignment.some(([, j]) => j === gi)).map((g) => g.name)
console.log("countries with no path:", unassignedGeo.join(", ") || "none")
writeFileSync("scripts/matches.json", JSON.stringify(out, null, 2))
